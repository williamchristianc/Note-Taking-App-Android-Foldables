# Folio – build handoff

This source archive is **not an APK**. An Android SDK and Gradle dependency downloads are required to compile it. This ChatGPT runtime did not have an Android SDK or reachable Maven/Gradle repositories, so the source could not be compiled or run here.

Changes compared with the uploaded source:
- Explicitly declares Compose animation and Material Icons Core dependencies, which are used by the app's Kotlin files.
- Keys the edit screen to the selected notebook so that form state does not carry over to a different notebook.

These changes have **not been validated by an Android build**. If the GitHub Actions build fails, retrieve the `folio-build-log` artifact and inspect the first `e:` or `error:` line, not just the stack trace at the end.

To build in the GitHub repository previously used:
1. Upload this archive as `Folio.zip` at the repository root (GitHub's file name must be `Folio.zip`).
2. Replace `.github/workflows/blank.yml` with the provided `build-apk.yml` content.
3. Open Actions → Build Folio APK → Run workflow.
4. On success, download the `folio-debug-apk` artifact and extract `app-debug.apk`.

The app is a Phase 1 notebook, **not** a complete Notion-like workspace yet. It has never been tested on an HONOR Magic V6.
